angular.module('myApp').controller('myCtrl', function($scope){
  $scope.test = 'most triumphant'
})
